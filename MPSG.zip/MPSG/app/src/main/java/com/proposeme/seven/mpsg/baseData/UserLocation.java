package com.proposeme.seven.mpsg.baseData;

/**
 * Created by seven on 2018/8/10
 * Describe: 保存用的地理位置，分为精度和维度。
 */
public class UserLocation {
    private String  loginID  = null;    //登录账号

}
