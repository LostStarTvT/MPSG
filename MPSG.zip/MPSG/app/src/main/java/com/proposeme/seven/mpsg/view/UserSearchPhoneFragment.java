package com.proposeme.seven.mpsg.view;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps2d.AMap;
import com.amap.api.maps2d.CameraUpdate;
import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.MapView;
import com.amap.api.maps2d.UiSettings;
import com.amap.api.maps2d.model.LatLng;
import com.amap.api.maps2d.model.Marker;
import com.amap.api.maps2d.model.MyLocationStyle;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.geocoder.GeocodeResult;
import com.amap.api.services.geocoder.GeocodeSearch;
import com.amap.api.services.geocoder.RegeocodeQuery;
import com.amap.api.services.geocoder.RegeocodeResult;
import com.proposeme.seven.mpsg.R;

import java.math.BigDecimal;

public class UserSearchPhoneFragment extends onTouchListenerFragment  implements GeocodeSearch.OnGeocodeSearchListener,AMap.InfoWindowAdapter,AMap.OnMarkerClickListener {


    //地图显示分为两个步骤， 1 通过监听器获取经纬度， 2 根据经纬度进行地图的显示。
    //1 声明AMapLocationClient类对象
    //这个对象只能通过监听器获取到地理位置经纬度，但是不能进行地图显示。
    public AMapLocationClient mLocationClient = null;

    //2 地图显示页面对象
    //这个对象是能够根据经纬度显示地图，
    MapView mMapView;
    AMap aMap = null; //地图控制器

    //测试的导航显示页面。
    private LatLng latLng;
    private LinearLayout call;
    private LinearLayout navigation;
    private TextView nameTV;
    private String agentName;
    private TextView addrTV;
    private String snippet;

    private Marker oldMarker;


    private AMapLocation mAMapLocation = null;  //记录获取到的经纬度坐标对象。
    private UiSettings mUiSettings;//定义一个UiSettings对象

    //解析地址对象。1 ，构造GeocodeSearch对象 搜索对象。
    private GeocodeSearch mGeocodeSearch;

    //fragment 中的初始化需要在下面的这个方法中进行。
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.user_search_phone, container, false);

        mMapView =  v.findViewById(R.id.MapShow); //找到地图的显示图层。
        mMapView.onCreate(savedInstanceState);

        initMapLocation(); //初始化获取地理位置。
        if (aMap == null) {
            aMap = mMapView.getMap();
        }

        initMapUiSettings(); //初始化UI配置。
        initMapBlueMarker(); //初始化蓝点显示

        //调节地图默认的显示精度。
        //设置显示的大小。从 3 到 19。数字越大，展示的图面信息越精细
        CameraUpdate mCameraUpdate = CameraUpdateFactory.zoomTo(17);
        aMap.animateCamera(mCameraUpdate);
        aMap.setInfoWindowAdapter(this);
        aMap.setOnMarkerClickListener(this);
        //aMap.setInfoWindowAdapter(AMap.InfoWindowAdapter.getClass());
        //启动定位
        mLocationClient.startLocation();

        return  v;
    }

    @Override
    public void onResume() {
        super.onResume();
        mMapView.onResume();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        mMapView.onDestroy();

    }


    @Override
    public void onPause() {

        super.onPause();
        mMapView.onPause();

    }

    //初始化定位函数，获取定位数据
    private  void  initMapLocation(){
        //初始化定位
        mLocationClient = new AMapLocationClient(getContext());
        //将定位配置与定位对象绑定
        mLocationClient.setLocationOption(getDefaultOption());
        //设置定位监听器
        mLocationClient.setLocationListener(mLocationListener);
    }

    //初始UI设置。即配置logo 缩放按钮，指南针等。
    private  void initMapUiSettings(){
        //实例化UiSettings类对象 即可以进行配置各种UI上的操作。 各种手势还有其他放大什么的。，
        mUiSettings = aMap.getUiSettings();
        mUiSettings.setMyLocationButtonEnabled(true); //显示默认的定位按钮 即上面那个定位按钮。
    }

    //初始化地图中显示的蓝点配置。
    private void initMapBlueMarker(){
        //设置蓝点分为三个步骤
        //1 实例化蓝点类，并且配置蓝点选项。
        MyLocationStyle myLocationStyle = new MyLocationStyle() ;
        myLocationStyle.interval(2000); //设置连续定位模式下的定位间隔，只在连续定位模式下生效，单次定位模式下不会生效。单位为毫秒。
        myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_FOLLOW_NO_CENTER) ;//连续定位、且将视角移动到地图中心点，定位蓝点跟随设备移动。（1秒1次定位）

        //2 将蓝点对象与AMap对象绑定。
        aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
        //3 开启蓝点显示。
        aMap.setMyLocationEnabled(true);// 设置为true表示启动显示定位蓝点，false表示隐藏定位蓝点并不进行定位，默认是false
    }




    //定位的配置设置函数
    private AMapLocationClientOption getDefaultOption(){
        AMapLocationClientOption mOption = new AMapLocationClientOption();
        mOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);//可选，设置定位模式，可选的模式有高精度、仅设备、仅网络。默认为高精度模式
        mOption.setGpsFirst(false);//可选，设置是否gps优先，只在高精度模式下有效。默认关闭
        mOption.setNeedAddress(true);//可选，设置是否返回逆地理地址信息。默认是true
//        mOption.setOnceLocationLatest(false);//可选，设置是否等待wifi刷新，默认为false.如果设置为true,会自动变为单次定位，持续定位时不要使用
        mOption.setSensorEnable(false);//可选，设置是否使用传感器。默认是false
        mOption.setWifiScan(true); //可选，设置是否开启wifi扫描。默认为true，如果设置为false会同时停止主动刷新，停止以后完全依赖于系统刷新，定位位置可能存在误差
//        mOption.setLocationCacheEnable(false); //可选，设置是否使用缓存定位，默认为true

        //mOption.setHttpTimeOut(30000);//可选，设置网络请求超时时间。默认为30秒。在仅设备模式下无效
        mOption.setInterval(5000);//可选，设置定位间隔。默认为2秒
        //mOption.setOnceLocation(false);//可选，设置是否单次定位。默认是false
        //mLocationOption.setOnceLocation(true);  //获取一次定位结果：

        return mOption;
    }

    //定位回调监听器
    public AMapLocationListener mLocationListener = new AMapLocationListener() {
        @Override
        public void onLocationChanged(AMapLocation aMapLocation) {
            mAMapLocation = aMapLocation;
            intiMessageAddress();
            if (aMapLocation != null) {
                if (aMapLocation.getErrorCode() == 0) {
                    //可在其中解析AMapLocation获取相应内容。
                    String msg ="维度：" + aMapLocation.getLatitude() + " " + "经度：" + aMapLocation.getLongitude();

// double latitude = aMapLocation.getLatitude();
// double longitude = aMapLocation.getLongitude();

                    Log.e("testAAAA",msg);

                    //在这里可以获取到经度和维度。那么就是之后直接根据经纬度进行逆转换
                }else {
                    //定位失败时，可通过ErrCode（错误码）信息来确定失败的原因，errInfo是错误信息，详见错误码表。
                    Log.e("AMapError","location Error, ErrCode:"
                            + aMapLocation.getErrorCode() + ", errInfo:"
                            + aMapLocation.getErrorInfo());
                }
            }
        }
    };


    //根据获取到的地址对象，解析其地址。
    private void intiMessageAddress(){

        //1,设置GeocodeSearch对象
        mGeocodeSearch = new GeocodeSearch(getContext());
        mGeocodeSearch.setOnGeocodeSearchListener(this);
        // Log.e("jingdu",mAMapLocation.getLatitude()+ "fff" + mAMapLocation.getLongitude());
        //主要是根据坐标反编译为地理位置。 首先是维度，之后是经度。这个不能乱。这个就是以后可以实现从服务器传递过来的
        //经纬度，经过定位后并且转为文字描述。
        LatLonPoint mLatLonPoint = new LatLonPoint(mAMapLocation.getLatitude(),mAMapLocation.getLongitude());
        //2，通过 ReGeocodeQuery(LatLonPoint point, float radius, java.lang.String latLonType) 设置查询参数，调用 GeocodeSearch 的 getFromLocationAsyn(RegeocodeQuery regeocodeQuery) 方法发起请求
        RegeocodeQuery query = new RegeocodeQuery(mLatLonPoint, 200,GeocodeSearch.AMAP);
        mGeocodeSearch.getFromLocationAsyn(query);

    }
    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        return null;
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        return false;
    }

    @Override
    public void onRegeocodeSearched(RegeocodeResult regeocodeResult, int i) {
        //解析reGeocodeResult 传递回来的结果。
        // String address = reGeocodeResult.getReGeocodeAddress().getFormatAddress().toString();
        //现在已经可以回调实现输出地理位置。
        String msg ="地址:"+ regeocodeResult.getRegeocodeAddress().getFormatAddress() + "附近";
        Log.e("reGeocodeResult",msg);
        Toast.makeText(getContext(), msg,
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onGeocodeSearched(GeocodeResult geocodeResult, int i) {

    }
}
