package com.proposeme.seven.mpsg.view;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

import com.proposeme.seven.mpsg.R;
import com.proposeme.seven.mpsg.ui.MainActivity;
import com.proposeme.seven.mpsg.util.L;
import com.skyfishjy.library.RippleBackground;

import ren.perry.perry.LoadingDialog;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by seven on 2018/9/11
 * Describe: 画一个按钮进行防盗开关的设定。
 */
public class MainViewFragment extends onTouchListenerFragment{

    private RippleBackground rippleBackground; //水波纹开关对象
    private ToggleButton  toggle;  //点击按钮
    private boolean isLocked; // 手机是否被锁住。

    //fragment 中的初始化需要在下面的这个方法中进行。
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        final android.support.v4.app.FragmentManager fm = getFragmentManager();

        View v = inflater.inflate(R.layout.main_frag, container, false);



        toggle = v.findViewById(R.id.TB_On_Off); //找到开关
        getLockedState(); //获取是否被锁

        //需要每次检测这个开关是否开启的吧？ 或者不需要？因为如果登录的时候 需要进行检测是否
        //已经开启防盗模式，但是不行，

        rippleBackground= v.findViewById(R.id.content);
        if (!isLocked){ //false为没有被锁，表示需要开启水波纹
            rippleBackground.startRippleAnimation();
        }
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                //进行跳转
                fm.beginTransaction().replace(R.id.frame_content,new NumPwdLockedFragment()).commit();
                if (isChecked){ //打开手机锁
                    rippleBackground.stopRippleAnimation();
                }else { //关闭手机锁
                    rippleBackground.startRippleAnimation();
                }
            }
        });
        return  v;
    }

    /*
        获取用户的手机是否解锁的状态。获取登录时保存的数据。
     */
    private void getLockedState(){
        //读取数据。
        SharedPreferences settings = getActivity().getSharedPreferences("UserLoginInfo", MODE_PRIVATE);
        isLocked = settings.getBoolean("userIsGuardOn",false);
        L.e("userIsGuard 2 " + isLocked);
        toggle.setChecked(isLocked);
    }

}
