package com.proposeme.seven.mpsg.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.proposeme.seven.mpsg.R;

/**
 *  此为测试各种控件的activity 可以随意修改
 **/

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }
}
